# TTK Downloader — Landing Page

A single-page, static site for **TikTok Video Downloader / TTK Downloader**, built to be published directly with **GitHub Pages**.

## Structure

```
.
├── index.html              # main page (all content + meta tags)
├── assets/
│   ├── css/
│   │   └── style.css       # all styling
│   └── images/
│       └── hero-banner.png # hero artwork, responsive on mobile
└── README.md
```

## Deploy on GitHub Pages

1. Create a new GitHub repository and push this folder's contents to the `main` branch (keep `index.html` at the repo root).
2. In the repo, go to **Settings → Pages**.
3. Under **Build and deployment → Source**, choose **Deploy from a branch**.
4. Pick branch `main` and folder `/ (root)`, then **Save**.
5. GitHub gives you a live URL such as `https://<your-username>.github.io/<repo-name>/` within a minute or two.

If you're using a custom domain (e.g. `ttkdownloader.com`), add a `CNAME` file at the repo root containing just the domain, and point your DNS `A`/`CNAME` records to GitHub Pages per [GitHub's custom domain docs](https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site).

## Notes

- All internal links use **relative paths** (`./assets/...`) so the site works whether it's served from a repo subpath (`username.github.io/repo/`) or a root custom domain.
- The hero image is responsive: it reflows to a taller crop at tablet (`≤820px`) and phone (`≤480px`) widths so it stays legible instead of shrinking into a thin strip.
- No build step or dependencies — pure HTML/CSS, so nothing needs installing before it goes live.
